// Adding & removing css style in js

var h1 = document.querySelector("h1");
h1.innerHTML = "hiiii"
console.log(h1)

//add css style
h1.classList.add('heading-style')

//removing css style
// h1.classList.remove('heading-style')