import {text as message} from './myModule.js'

console.log(message)
