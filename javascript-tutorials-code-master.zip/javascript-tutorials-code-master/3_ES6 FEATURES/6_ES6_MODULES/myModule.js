export let text = "Welcome to module";


