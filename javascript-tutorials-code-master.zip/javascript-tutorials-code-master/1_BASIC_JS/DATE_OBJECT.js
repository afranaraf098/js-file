var date = new Date();
console.log(date)

var year = date.getFullYear();
console.log(year)

var month = date.getMonth();
console.log(month)

var currentDate = date.getDate();
console.log(currentDate)

var currentDay = date.getDay();
console.log(currentDay)

var currentHour = date.getHours();
console.log(currentHour)

var currentMinutes = date.getMinutes();
console.log(currentMinutes)