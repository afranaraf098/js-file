// output functions -> functions that will help you to show output
// document.write(), console.log(), alert()


document.write("Welcome to JS Program");
document.write("<h1>Welcome to JS Program</h1>");
document.write("<h2>Welcome to JS Program</h2>");


console.log("Welcome to JS Program");

//this alert() will display an alert message 
alert("welcome to js program");