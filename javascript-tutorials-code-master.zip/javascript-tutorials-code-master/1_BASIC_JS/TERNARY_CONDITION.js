var number = Number(prompt("Enter a number "));
var result = number>0 ? "positive" : number<0 ? "Negative" : "zero";
console.log(result)

