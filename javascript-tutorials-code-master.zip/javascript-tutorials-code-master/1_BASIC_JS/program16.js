// A program to demonstrate do while loop
// do while loop syntax
var i = 1;
do {
    document.write("Bangladesh" + "<br>");
    i++;
} while (i <= 10);

document.write("End of for loop");


// sum of numbers 1+2+..+100
// var sum = 0;
// var x = 1;
// do{
//     sum = sum + x;
//     x++;
// }while ( x <= 100)
// document.write(sum);