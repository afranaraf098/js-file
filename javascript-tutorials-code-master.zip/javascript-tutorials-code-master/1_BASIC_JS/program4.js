//you can run this program by using the command =>   node program4 .js


// string  -> a sequnces of characters
// string concatenation -> adding multiple strings


var fName = "Anisul";
var lName = "Islam";

// adding multiple strings here
var fullName = fName + " " + lName;
console.log(fullName);
console.log("Today is" + " a " + "beautiful day");
console.log("My name is " + fullName)


var num1 = 20;
var num2 = 30;
var sum = num1 + num2;
console.log(num1 + " + " + num2 + " = " + sum);