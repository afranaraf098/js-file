//A program to demonstrate for loop

// for loop syntax
for (var i = 1; i <= 10; i++) {
    document.write("Bangladesh" + "<br>");
}

document.write("End of for loop");


// sum of numbers 1+2+..+100
// var sum = 0;
// for (var x = 1; x <= 100; x++){
//     sum = sum + x;
// }
// document.write(sum);